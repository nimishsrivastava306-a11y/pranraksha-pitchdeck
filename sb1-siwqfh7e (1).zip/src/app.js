let currentSlide = 0;
const totalSlides = 10;
let isTransitioning = false;

function updateSlide() {
  if (isTransitioning) return;

  isTransitioning = true;
  const slides = document.querySelectorAll('.slide');

  slides.forEach((slide) => {
    slide.classList.remove('active');
  });

  setTimeout(() => {
    slides[currentSlide].classList.add('active');
    isTransitioning = false;
  }, 50);

  updateProgress();
  saveProgress();

  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
}

function nextSlide() {
  if (currentSlide < totalSlides - 1) {
    currentSlide++;
    updateSlide();
  }
}

function prevSlide() {
  if (currentSlide > 0) {
    currentSlide--;
    updateSlide();
  }
}

function updateProgress() {
  const progressBar = document.getElementById('progressBar');
  const progress = ((currentSlide + 1) / totalSlides) * 100;
  progressBar.style.width = `${progress}%`;
}

function saveProgress() {
  localStorage.setItem('pranraksha-slide', currentSlide);
}

function loadProgress() {
  const savedSlide = localStorage.getItem('pranraksha-slide');
  if (savedSlide !== null) {
    currentSlide = parseInt(savedSlide, 10);
    if (currentSlide >= totalSlides) {
      currentSlide = 0;
    }
  }
  updateSlide();
}

function openLightbox(src) {
  const lightbox = document.getElementById('lightbox');
  const lightboxImage = document.getElementById('lightboxImage');
  lightboxImage.src = src;
  lightbox.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeLightbox() {
  const lightbox = document.getElementById('lightbox');
  lightbox.classList.remove('active');
  document.body.style.overflow = 'auto';
}

document.addEventListener('keydown', (event) => {
  if (event.key === 'ArrowRight') {
    nextSlide();
  } else if (event.key === 'ArrowLeft') {
    prevSlide();
  } else if (event.key === 'Escape') {
    closeLightbox();
  }
});

let touchStartX = 0;
let touchEndX = 0;

document.addEventListener('touchstart', (event) => {
  touchStartX = event.changedTouches[0].screenX;
}, { passive: true });

document.addEventListener('touchend', (event) => {
  touchEndX = event.changedTouches[0].screenX;
  handleSwipe();
}, { passive: true });

function handleSwipe() {
  const swipeThreshold = 50;
  if (touchEndX < touchStartX - swipeThreshold) {
    nextSlide();
  } else if (touchEndX > touchStartX + swipeThreshold) {
    prevSlide();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadProgress();

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (prefersReducedMotion.matches) {
    document.body.classList.add('reduced-motion');
  }
});

window.addEventListener('beforeunload', () => {
  saveProgress();
});
